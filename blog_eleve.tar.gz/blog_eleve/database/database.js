/* const Sequelize = require("sequelize") ;
const  connection = new Sequelize("blog_eleve", "root","12345",{
    host: 'localhost',
    dialect:'mysql'
});

module.exports= connection; */

